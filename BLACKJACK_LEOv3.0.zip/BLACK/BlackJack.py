#-*- coding:utf-8 -*-

import random
import time
import msvcrt


# define Card
class Card:
    """define class Card"""

    def __init__(self, card_type, card_text, card_value):
        """
        card_type:  红桃  黑桃  方片   梅花
        card_text:  A 2 3 4 5 6 7 8 9 10 J Q K
        card_value: 1~11
        """
        self.card_type = card_type
        self.card_text = card_text
        self.card_value = card_value

class Player:

    def __init__(self, name):
        self.name = name
        self.cards = []

    def show_cards(self):
        print(self.name + "'s Cards:")
        # sum = 0
        for card in self.cards:
            print(card.card_type.encode('gbk', 'ignore').decode('gbk'), card.card_text, card.card_value)
            # sum += card.card_value
        sum = self.get_value()
        print("总点数："+str(sum)+"\n")

    def show_one_Card(self, num=1):
        print(self.name + "'s Cards:")
        print(self.cards[num-1].card_type.encode('gbk', 'ignore').decode('gbk'), self.cards[num-1].card_text, self.cards[num-1].card_value)
        print("总点数："+str(self.cards[num-1].card_value)+"\n")

    def get_value(self):
        sum = 0
        A_count = 0
        for card in self.cards:
            sum += card.card_value
            if (card.card_text == 'A'):
                A_count += 1
        if sum>21 and A_count>0:
            sum = sum - 10
            A_count -= 1
        return sum

    def fail_condition(self):
        return self.get_value() > 21


class GameController:

    def __init__(self):
        self.cards = []
        all_card_type = ["♥ 红桃","♠ 黑桃","♦ 方片","♣ 梅花"]
        all_card_text = ["A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2"]
        all_card_value = [11, 10, 10, 10, 10, 9, 8, 7, 6, 5, 4, 3, 2]
        for card_type in all_card_type:
            for index, card_text in enumerate(all_card_text):
                card = Card(card_type, card_text, all_card_value[index])
                self.cards.append(card)
        random.shuffle(self.cards)

    def send_card(self, Player, num = 1):
        for i in range(num):
            card = self.cards.pop()
            Player.cards.append(card)

def main():
    # testing
    # Card1 = Card
    # Card1.card_type = '♠ 黑桃'
    # Card1.card_text = 'A'
    # Card1.card_value = 11
    # score = 0
    weight = 1

    Game = GameController()
    print("==========阶段1===========")
    Boss = Player('庄家')
    Rookie = Player('玩家')

    time.sleep(1)
    print("发牌中...")

    # Method 1
    Game.send_card(Boss)
    Game.send_card(Rookie)
    Game.send_card(Boss)
    Game.send_card(Rookie)
    Boss.show_one_Card()
    Rookie.show_cards()

    # Method 2
    # Game.send_card(Boss)
    # Game.send_card(Rookie, 2)
    # Boss.show_cards()
    # Rookie.show_cards()
    # Game.send_card(Boss)

    print("==========阶段2===========")
    choice1 = input("请给出您的选择（请输入编号）？【1.要一张牌/2.不再要牌/3.认输】")
    if (choice1 == '3'):
        score = -weight
        print("认输，游戏重新开始！您的筹码:" + str(score))
        return score
    elif (choice1 == '1'):
        weight += 1
        Game.send_card(Rookie)
        Rookie.show_cards()
        if Rookie.fail_condition():
            score = -weight
            print("爆牌，您输掉了这局比赛！ 您的筹码:" + str(score))
            return score
        while True:
            choice2 = input("请给出您的选择（请输入编号）？【1.要一张牌/2.不再要牌】")
            if (choice2=='1'):
                weight += 1
                Game.send_card(Rookie)
                Rookie.show_cards()
                if Rookie.fail_condition():
                    score = -weight
                    print("爆牌，您输掉了这局比赛！ 您的筹码:"+str(score))
                    return score
            else:
                break



    print("==========阶段3===========")
    print("庄家亮牌...")
    time.sleep(1)
    while True:
        Boss.show_cards()
        Rookie.show_cards()
        if Boss.fail_condition():
            score = weight
            print("庄家爆牌，您赢了！您的筹码:"+str(score))
            return score
        elif Boss.get_value() >= 17:
            break
        else :
            print("庄家点数不足17，继续发牌...")
            Game.send_card(Boss)



    Rookie_value = Rookie.get_value()
    Boss_value = Boss.get_value()
    if Rookie_value > Boss_value:
        score = weight
        print("您赢了！您的筹码:"+str(score))
    elif Rookie_value == Boss_value:
        score = 0
        print("平局！您的筹码:"+str(score))
    else:
        score = -weight
        print("您输了！您的筹码:"+str(score))

    return str(score)




if __name__ == '__main__':
    main()
    input('请按下 <Enter> 退出游戏...')



